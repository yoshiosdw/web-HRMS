<template>
  <div class="demo-space-x">
    <VAvatar
      rounded="0"
      color="primary"
    >
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar
      rounded="sm"
      color="secondary"
    >
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar
      rounded
      color="success"
    >
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar
      rounded="lg"
      color="info"
    >
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar
      rounded="xl"
      color="warning"
    >
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>

    <VAvatar color="error">
      <VIcon
        color="white"
        size="25"
        icon="tabler-user"
      />
    </VAvatar>
  </div>
</template>
