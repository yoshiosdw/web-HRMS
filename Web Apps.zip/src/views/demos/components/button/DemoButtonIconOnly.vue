<template>
  <div class="demo-space-x">
    <VBtn
      icon="tabler-briefcase"
      variant="text"
    />

    <VBtn
      icon="tabler-user-plus"
      variant="text"
      color="secondary"
    />

    <VBtn
      icon="tabler-search"
      variant="text"
      color="success"
    />

    <VBtn
      icon="tabler-thumb-up"
      variant="text"
      color="info"
    />

    <VBtn
      icon="tabler-star"
      variant="text"
      color="warning"
    />

    <VBtn
      icon="tabler-heart"
      variant="text"
      color="error"
    />
  </div>
</template>
