<template>
  <VAlert color="primary">
    Good Morning! Start your day with some alerts.
  </VAlert>
</template>
