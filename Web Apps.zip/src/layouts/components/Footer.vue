<template>
  <div class="h-100 d-flex align-center justify-space-between">
    <!-- 👉 Footer: left content -->
    <span class="d-flex align-center">
      &copy;
      {{ new Date().getFullYear() }}
      Made By 
      <a
        target="https://lidahbuayagroup.com"
        rel="noopener noreferrer"
        class="text-primary ms-1"
      >LIDAH BUAYA GROUP</a>
    </span>
  </div>
</template>
