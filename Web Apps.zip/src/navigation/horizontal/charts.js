export default [
  {
    title: 'Charts',
    icon: { icon: 'tabler-chart-donut' },
    children: [
      { title: 'Apex Chart', to: 'charts-apex-chart', icon: { icon: 'tabler-chart-line' } },
      { title: 'Chartjs', to: 'charts-chartjs', icon: { icon: 'tabler-chart-pie' } },
    ],
  },
]
