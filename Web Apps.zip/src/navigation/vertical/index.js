import configuration from './configuration'
import dashboard from './dashboard'
import emplyment from './emplyment'


export default [...emplyment, ...dashboard]
