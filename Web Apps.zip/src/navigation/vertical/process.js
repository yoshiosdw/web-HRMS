export default [
  {
    heading: "LOGISTIC PROCESS",
    action: "Read",
    subject: "Role",
  },
  {
    title: "Booking Order",
    icon: { icon: "solar:notebook-linear" },
    action: "Read",
    subject: "Role",
  },
  {
    title: "Baging",
    icon: { icon: "tabler:paper-bag" },
    action: "Read",
    subject: "Role",
  },
  {
    title: "Loading List",
    icon: { icon: "material-symbols:list-alt-check-outline-rounded" },
    action: "Read",
    subject: "Role",
  },
  {
    title: "Loading",
    icon: { icon: "mdi:cart-arrow-down" },
    action: "Read",
    subject: "Role",
  },
];
