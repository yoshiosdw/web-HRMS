export default [
  {
    heading: "Configuration",
    action: "Read",
    subject: "Dashboard",
  },
  {
    title: "Sync Logs",
    to: { name: 'inquiries'},
    icon: { icon: "ion:ios-options" },
    action: "Read",
    subject: "Dashboard",
  },
  {
    title: "Sikel",
    icon: { icon: "ion:ios-options" },
    action: "Read",
    subject: "Dashboard",
  },
];
  